<?php

include_once '../model/masterModel.php';

class NosotrosModel extends MasterModel{
    //put your code here
}
