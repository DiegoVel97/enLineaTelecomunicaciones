<?php

include_once '../model/masterModel.php';

class NoticiasModel extends MasterModel{
    //put your code here
}
