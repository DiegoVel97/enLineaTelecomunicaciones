<?php

include_once '../model/masterModel.php';

class bannerModel extends MasterModel{
    //put your code here
}
