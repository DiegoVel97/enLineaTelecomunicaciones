<?php

include_once '../model/masterModel.php';

class navegacionModel extends MasterModel{
    //put your code here
}
