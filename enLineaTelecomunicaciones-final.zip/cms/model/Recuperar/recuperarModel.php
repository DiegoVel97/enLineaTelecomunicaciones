<?php

include_once('../model/masterModel.php');

class recuperarModel extends MasterModel {
  
}
