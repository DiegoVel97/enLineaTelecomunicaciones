<?php
include_once('../model/masterModel.php');

class planesModel extends MasterModel{
   
}