<?php
include_once('../model/masterModel.php');

class SesionModel extends MasterModel{
   
}