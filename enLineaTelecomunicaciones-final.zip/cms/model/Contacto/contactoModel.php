<?php

include_once '../model/masterModel.php';

class ContactoModel extends MasterModel{
    //put your code here
}
