<?php

include_once('../model/Recuperar/recuperarModel.php');

class recuperarController{

    function envioMails(){
        echo "Hola Mundo";
    }
}


