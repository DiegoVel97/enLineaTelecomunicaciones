<?php

define("NOMBRE_APLICATIVO", "ENLINEA TELECOMUNICACIONES");
define("NOMBRE_COMPLETO_APLICATIVO", "Gestion de Mantenimiento sitio web");
define("FECHA_ACTUAL", $fechaActual= date("Y")."-".date("n")."-".date("j"));