<div class="col s3">
    <label for="cnhors">(*) Cantidad Horas</label>
    <input id="cnhors" type="text" class="validate" name="cnhors" data-error=".errorTxt13">
    <div class="errorTxt13"></div>
</div>
<div class="col s3">
    <label for="vsueldo">(*) Valor Sueldo</label>
    <input id="vsueldo" type="text" class="validate" name="vsueldo" data-error=".errorTxt14" >
    <div class="errorTxt14"></div>
</div>